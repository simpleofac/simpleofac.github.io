---
layout: sarctr
title: OFAC Suite Screenshot Tour
slug: ofac
---
###SAR CTR Screenshot Tour

<div class="row">
  <div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/sarctr/images/sar-result.png">
            <img src="{{site.url}}/sarctr/images/sar-result.png" alt="Manage SAR (Suspicious Activity Report)"
                    ></a>
			<p><span class="label label-info">Suspicious Activity Report:</span> All sections of the SAR, such as Filing institution, Suspects, Suspects Activities etc are in the same screen for easy management.</p>
	 </div>
 </div>
 <div class="span10">
	 <div class="thumbnail2">
		<a href="{{site.url}}/sarctr/images/ctr-result.png">
            <img src="{{site.url}}/sarctr/images/ctr-result.png" alt="Manage CTR(Currency Transaction Report)."
                   ></a>                   
			<p><span class="label label-info">Currency Transaction Report:</span> All sections of the CTR, such Filing institution, Person involved, Transaction summary etc. are in the same screen for easy management</p>
	 </div>
 </div>

<div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/sarctr/images/sar-workflow.png">
            <img src="{{site.url}}/sarctr/images/sar-workflow.png" alt="CTR SAR Configurable workflow"
                   ></a>
			<p><span class="label label-info">Configurable Workflow:</span> update CTR, SAR, attach documents, add comments etc. with easy configurable workflow.</p>
	 </div>
 </div>

</div>

For more information on SAR, CTR, and E-filing, please check the [online documentation]({{site.url}}help/en/).
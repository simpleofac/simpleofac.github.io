---
layout: sarctr
title: FINCEN SAR CTR Overview
slug: sarctr
---

###Our approach to regulatory reporting

FINCEN SAR, CTR and E-Filing is a build-in module of SimpleCompli Platform. 
It uses the latest Web 2.0 (AJAX), providing user friendly interface, high performance, and quality.

<p class="lead">
What can you expect from SAR, CTR and E-filing module:
</p>


1.  **Manage your CTR, SAR**  
    Automatically generate CTRs and/or SARs if you are using our Detection module. 
    Easily pre-populate basic information, such as Filing Financial Institutions, Transmitter, etc.

2.  **Search and Copy**  
    Various search functions make it easy to find your CTR/SAR. Create a new CTR or SAR in a few minutes with copy function.

3.  **Automatic Validation**   
    Validate all the user input before it is saved and generate batch files for E-file submission. 
    Batch E-file has been fully tested in the BSA E-file test system. It will not be rejected by FINCEN due to format or data quality.

4.  **Workflow and Notification**  
    It has easy to use, configurable workflow and built-in support for document management, email, and audit log.



For more information on SAR, CTR, and E-filing, please check the [online documentation]({{site.url}}/sarctr/help/en/).



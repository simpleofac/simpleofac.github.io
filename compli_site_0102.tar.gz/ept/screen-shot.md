---
layout: ept
title: EPT Screenshot Tour
slug: ept
---
###SimpleEPT Screenshot Tour

<div class="row">
  <div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/ept/images/preclearance-search-result.png">
            <img src="{{site.url}}/ept/images/preclearance-search-result.png" alt="Access Person Pre-clearance request"
                    ></a>
			<p><span class="label label-info">Pre-clearance request</span> by Access person.</p>
	 </div>
 </div>
 <div class="span10">
	 <div class="thumbnail2">
		<a href="{{site.url}}/ept/images/apcertification-update.png">
            <img src="{{site.url}}/ept/images/apcertification-update.png" alt="Access person certification submission"
                   ></a>                   
			<p><span class="label label-info">Certification</span> submitted by Access person</p>
	 </div>
 </div>
  <div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/ept/images/holdingposition-search-result.png">
            <img src="{{site.url}}/ept/images/holdingposition-search-result.png" alt="Access person holding and pesition"
              ></a>
			<p><span class="label label-info">Holding and position</span>for access person.</p>
			
	 </div>
 </div>

<div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/ept/images/rule-search-result.png">
            <img src="{{site.url}}/ept/images/rule-search-result.png" alt="Rules - Detection Builder"
                   ></a>
			<p><span class="label label-info">Rules</span> built with detection builder</p>
	 </div>
 </div>


</div>

For more information on SimpleEPT™ , please check the [online documentation]({{site.url}}help/en/).
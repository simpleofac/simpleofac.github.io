---
layout: ept
title: Employee Person Trade Compliance
slug: ept
---

###Our approach to Employee Person Trade Monitoring

Employee Person Trade (SimpleEPT) is a build-in module of SimpleCompli platform. 
It uses the same advanced rule engine AML module uses and the latest Web 2.0 (AJAX), providing user friendly interface, high performance, and quality.

SimpeEPT greatly simplifies the compliance process, reduces paperwork, improves visibility and avoid SEC-imposed non-compliance fines.  

<p class="lead">
Major features and functionalities are:
</p>

1.  **Rule builder**  
    It allows the compliance officer to build pre-clearance and/or post-trade rules to 
    comply with SEC rules, ICI recommendations, and the firm's code of ethics. 
    
2.  **Trade pre-clearance**  
    Employees can submit pre-trade authorization requests. Those requests will be run against firm's trade rules. 
    They will be auto approved, auto denied, or escalated to the manager or compliance officer based on the configuration.  
    
3.  **Post trade monitoring**   
    Broker confirmation will also be recorded and run against post trade rules. Any violations(exception) will be reviewed and resolved 
    by compliance officer with configurable workflow. 
    
4.  **Disclosure and Certification.**  
    Employees can easily disclose the broker accounts. 
    The certification of those accounts can be scheduled to be completed at appropriate intervals.

5.	**Easy reporting.**      
    It has various build-in reports. Adding a new report is easy by simply adding a new Jasperreport template. 
     


For more information on SimpleEPT, please check the [online documentation]({{site.url}}/ept/help/en/).



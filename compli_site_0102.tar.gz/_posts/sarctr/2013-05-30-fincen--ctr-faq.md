---
layout: post
categories: 
- regulatory
tags:
- SAR CTR

title:  The Newest SAR and CTR FAQs from FINCEN
Summary: What changes in Fincen SAR CTR and DOEP
---

###{{page.title}}

On May 24, 2013, the Financial Crimes Enforcement Network (FinCEN) released two sets of frequently asked questions(FAQs): 
[FAQs Regarding SARs](http://fincen.gov/whatsnew/html/sar_faqs.html) and [FAQs Regarding CTRs](http://fincen.gov/whatsnew/html/ctr_faqs.html).
The purpose of these questions is to assist financial institutions with the use of FinCEN’s new SAR and CTR forms, which, as of April 1, 2013, are the only acceptable forms for reporting suspicious activity and applicable currency transactions.

The FAQs are very detailed, and if you have any dealings with SARs or CTRs at your institution, 
I’d suggest you read through them. Here are some of information from the FAQs Regarding SARs:


1. **What are the expectations for completing the Items with an asterisk (“critical”) and without an asterisk (“non-critical”) found on the FinCEN SAR or any other FinCEN report?**

    As explained in FinCEN’s March 2012 guidance (FIN-2012-G002), for both critical and non-critical elements, financial institutions should complete those Items for which they have relevant information, regardless of whether or not the individual Items are deemed critical for technical filing purposes.

    For critical Items, financial institutions must either provide the requested information or affirmatively check the “Unknown” (Unk.) box that is provided on the FinCEN SAR and FinCEN Currency Transaction Report (CTR) (or any other FinCEN Report).

    For non-critical Items, FinCEN expects financial institutions will provide the most complete filing information available within each report consistent with existing regulatory expectations. Based upon feedback from law enforcement officials, such information is important for query purposes. However, the new FinCEN SAR and FinCEN CTR do not create any new obligations to collect data, either manually or through an enterprise-wide IT management system, where such collection is not already required by current statutes and regulations, especially when such collection would be in conflict with the financial institution’s obligations under any other applicable law. Therefore, a financial institution may leave non-critical fields without an asterisk blank when information is not readily available.

2. **How do I meet my underlying obligation to submit a complete and accurate report if my filing software does not allow me to include known information for a field without an asterisk?**

    FinCEN expects financial institutions to have the capability to submit information for any of the data fields in the FinCEN SAR or CTR (or any other FinCEN report). In general, if your financial institution’s filing software does not permit the institution to include information in a field without an asterisk where information has been collected and is pertinent to the report, the financial institution should instead complete a discrete filing for those transactions until the software is updated. If a filing has been submitted in which such information was not included because of such a limitation in the filing software, an amended filing should be completed using either the discrete filing method or an amended batch filing, once the software is updated. Such software updates should be implemented within a reasonable period of time.

3. **What is the timeframe for filing the FinCEN CTR? I have seen both 15 and 25 days referenced.**

    FinCEN regulations have consistently maintained a regulatory requirement that CTRs be filed within 15 days. The 25-day period was implemented, in connection with receipt of magnetic media files (ended December 2008), to account for physically transporting (shipping) the magnetic media to the processing center in Detroit, Michigan. FinCEN understands that this business practice had continued with respect to batch e-filing, particularly considering previous public guidance referencing the 25-day period.

    In light of the comments received and acknowledging that some financial institutions may have needed to change their business processes to become compliant with the rules, FinCEN determined that it would temporarily maintain the 25-day compliance period referenced in its earlier specifications until March 31, 2013, for those filers that needed to update their systems in order to be in compliance with the established regulatory requirements. This temporary extension to the filing requirements was to allow sufficient time for filers to adjust submission schedules to meet established regulatory requirements.

    As of April 1, 2013, all FinCEN CTRs must be filed within 15 calendar days of the reported transaction(s).

Please refer to [FINCEN's website](http://fincen.gov/whatsnew/html/sar_faqs.html) for more information.

If your institution has questions regarding the applicability of this general guidance, please contact the FinCEN Regulatory Helpline at (800) 949-2732 for further information.
       
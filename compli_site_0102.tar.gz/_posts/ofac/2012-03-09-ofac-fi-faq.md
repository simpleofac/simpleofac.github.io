---
layout: post
categories: 
- FAQ
tags:
- OFAC
 
title: General OFAC Questions for Financial Institution
summary: Some General OFAC Questions for Financial Institution from OFAC's website, such as 
         <ul>
         <li>  1.  How often do I need to scan my customer database for SDNs? 
         <li>  2.  What are the features and benefits that banks should be looking for when selecting an OFAC compliance software package?
         <li>  3.  Does a financial institution need to scan names against OFAC's list of targets upon account opening or can it wait for 24 hours to receive a report from its software vendor on whether or not there is a hit?  
         </ul>
---

###{{page.title}}

28. **How often do I need to scan my customer database for SDNs?**

      The frequency of running an OFAC scan must be guided by your internal bank policy and procedures. Keep in mind, however, that if your bank fails to identify and block a target account (of a terrorist, for example), there could be "real world" consequences such as a transfer of funds or other valuable property to an SDN, an enforcement action against your bank, and negative publicity.


31. **What are the features and benefits that banks should be looking for when selecting an OFAC compliance software package?**

      There are a wide variety of software packages available to the financial community. The size and needs of each institution help to determine what to look for in a package. Some packages are used to interdict sanctioned countries and SDN names in wire transfers, while others are used to check the names of new customers; other packages also filter the names of all account holders. One suggestion for finding the right software for your bank is to research what your peer banks are using and determine if the software package is working for them. Your bank also could talk to a variety of software vendors who can easily be located by doing an Internet search.
      
43. **Does a financial institution need to scan names against OFAC's list of targets upon account opening or can it wait for 24 hours to receive a report from its software vendor on whether or not there is a hit?**

      There is no legal or regulatory requirement to use software or to scan. There is a requirement, however, not to violate the law by doing business with a target or failing to block property. OFAC realizes that financial institutions use software that does not always provide an instantaneous response and may require some analysis to determine if a customer is indeed an SDN. The important thing is not to conclude transactions before the analysis is completed.
      

For more information, please check [OFAC's Website](http://www.treasury.gov/resource-center/faqs/Sanctions/Pages/ques_index.aspx#finance)      
      
      
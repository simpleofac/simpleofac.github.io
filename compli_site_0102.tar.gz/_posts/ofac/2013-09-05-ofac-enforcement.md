---
layout: post
categories: 
- regulatory
tags:
- OFAC

title:  Release of OFAC Enforcement Information - September 5, 2013
summary:  Specially Designated Nationals List Update  

---

###{{page.title}}


New OFAC enforcement information was released on September 5, 2013

Content can be found at [Here]({{ site.url }}/resources/20130905_DBTCA.pdf)      

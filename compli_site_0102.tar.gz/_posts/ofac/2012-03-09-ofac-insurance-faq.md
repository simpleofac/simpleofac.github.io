---
layout: post
categories: 
- FAQ
tags:
- OFAC
 
title: General OFAC Questions for  Insurance Industry
summary: Some General OFAC Questions for  Insurance Industry from OFAC's website, such as 
         <ol>
     	  <li>At what point must an insurer check to determine whether an applicant for a policy is an SDN?
     	  <li>What should an insurer do if it discovers that a policyholder is or becomes an SDN--cancel the policy, void the policy ab initio, non-renew the policy, refuse to pay claims under the policy? Should the claim be paid under a policy issued to an SDN if the payment is to an innocent third-party (for example, the injured party in an automobile accident)?
     	  <li>A workers' compensation policy is with the employer, not the employee. Is it permissible for an insurer to maintain a worker's compensation policy that would cover a person on the SDN List, since the insurer is not transacting business with the SDN, but only with his/her employer?
     	  <li>How frequently is an insurer expected to scrub its databases for OFAC compliance?
     	  <li>Is it sufficient if my company screens life insurance policies only prior to policy issuance?
     	  <li>If my policyholder, who is a U.S. person, requests a change of beneficiaries and designates a cousin living in Cuba as a beneficiary under the life insurance policy, what shall I do?
     	  <li>If my screening efforts uncover a policyholder who became an SDN after policy issuance, can I notify the policyholder that the policy is “blocked”?         
         </ol>
---

###{{page.title}}

1.  **At what point must an insurer check to determine whether an applicant for a policy is an SDN?**

      If you receive an application from an SDN for a policy, you are under an obligation not to issue the policy. Remember that when you are insuring someone, you are providing a service to that person. You are not allowed to provide any services to an SDN. If the SDN sends a deposit along with the application, you must block the payment.

2.  **What should an insurer do if it discovers that a policyholder is or becomes an SDN--cancel the policy, void the policy ab initio, non-renew the policy, refuse to pay claims under the policy? Should the claim be paid under a policy issued to an SDN if the payment is to an innocent third-party (for example, the injured party in an automobile accident)?**

      The first thing an insurance company should do upon discovery of such a policy is to contact OFAC Compliance. OFAC will work with you on the specifics of the case. It is possible a license could be issued to allow the receipt of premium payments to keep the policy in force. Although it is unlikely that a payment would be licensed to an SDN, it is possible that a payment would be allowed to an innocent third party. The important thing to remember is that the policy itself is a blocked contract and all dealings with it must involve OFAC.

3.  **A workers' compensation policy is with the employer, not the employee. Is it permissible for an insurer to maintain a workers compensation policy that would cover a person on the SDN List, since the insurer is not transacting business with the SDN, but only with his/her employer?**

      If an insurer knows that a person covered under the group policy is an SDN, that person’s coverage is blocked, and if he or she makes a claim under the policy, the claim cannot be paid. If an insurer does not know the names of those covered under a group policy, it would have no reason to know it needed to block anything unless and until an SDN files a claim under that policy. At that point its blocking requirement would kick in.

4.  **How frequently is an insurer expected to scrub its databases for OFAC compliance?**

      That is up to your firm and your regulator. Remember that a critical aspect of the designation of an SDN is that the SDN's assets must be frozen immediately, before they can be removed from U.S. jurisdiction. If a firm only scrubs its database quarterly, it could be 3 months too late in freezing targeted assets. The SDN list may be updated as frequently as a few times a week or as rarely as once in six months.

5.  **Is it sufficient if my company screens life insurance policies only prior to policy issuance?**

      That’s up to your firm and your regulators. Conducting screening only before policy issuance is critical but would not likely achieve your desired level of compliance. After the policy issuance, the U.S. Government may designate an existing policyholder or a named beneficiary as a Specially Designated National or Blocked Person (“SDN”), or it may expand sanctions with respect to a particular country, or impose sanctions against a new country. If an existing policyholder or a named beneficiary became an SDN or otherwise subject to U.S. sanctions, the insurer may be required to “block” the policy, report such blocking to OFAC within 10 days of the SDN designation, place any future premiums into a blocked, interest-bearing account at a U.S. financial institution, and seek an OFAC license before making any payments under the policy. Consequently, routine screening of all policies in force against OFAC’s SDN list, as frequently updated, would enable the insurer to comply with the applicable OFAC regulatory requirements. It also is important to screen the policyholder and beneficiary prior to paying a claim.

6.  **If my policyholder, who is a U.S. person, requests a change of beneficiaries and designates a cousin living in Cuba as a beneficiary under the life insurance policy, what shall I do?**

      In general, an insurance policy is considered “property” and a beneficiary’s interest in the policy is considered an “interest in property” that may require blocking under the applicable regulations. The Cuban Assets Control Regulations, however, contain a general license that deals with transactions involving blocked life insurance policies. 31 C.F.R. § 515.526. In this case, the only blocked interest is that of a beneficiary, so the general license would authorize the insurer to accept premium payments and interest on policy loans as well as to pay loans to the insured or process the insured’s request for a change of beneficiary. Also, the insurer would be authorized under the general license to deduct premiums from cash surrender value, if any, or accumulate dividends or otherwise increase cash surrender value on the books of the insurer, pursuant to the terms of the policy. However, the insurer usually cannot pay an entire claim (the face amount of the policy) to the beneficiary without a specific license from OFAC. Recent amendments to the Cuba regulations authorize by general license remittances to a Cuban beneficiary of up to $300 per quarter from a blocked account at a U.S. banking institution if the funds in that account were deposited there as a result of a payment from a life insurance policy triggered by the death of the policy holder. If you have a blocked policy, you should seek legal advice or contact OFAC for further guidance regarding the handling of that particular account.

7.  **If my screening efforts uncover a policyholder who became an SDN after policy issuance, can I notify the policyholder that the policy is “blocked”?**

      Yes, the insurer may notify the policyholder that the policy is blocked, without obtaining a specific license from OFAC.

For more information, please check [OFAC's Website](http://www.treasury.gov/resource-center/faqs/Sanctions/Pages/ques_index.aspx#insurance)      
      
      
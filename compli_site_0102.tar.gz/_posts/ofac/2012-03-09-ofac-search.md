---
layout: post
categories: 
- Free Tools
tags:
- OFAC
 
title: Free OFAC SDN search tools
summary: List of free online ofac search tools and frequent SDN Search Questions from OFAC webiste.
---
###{{page.title}}

For those we are looking for free online ofac search tools, the following's are the lists

1.  [https://www.simpleofac.com/free-ofac-search.jsp](https://www.simpleofac.com/free-ofac-search.jsp) 
2.  [http://www.instantofac.com](www.instantofac.com) 
4.  [http://apps.finra.org/rulesregulation/ofac/1/default.aspx](http://apps.finra.org/rulesregulation/ofac/1/default.aspx)
5.  [http://sdnsearch.ofac.treas.gov](http://sdnsearch.ofac.treas.gov/)  

Please try them out!.


###SDN Search Questions from OFAC webiste


1. **How does SDN Search work?**

     In addition to returning results that are exact matches (when the match threshold slider bar is set to 100%), SDN Search can also provide a broader set of results using fuzzy logic. This logic uses character and string matching as well as phonetic matching. Only the name field of SDN Search invokes fuzzy logic when the tool is run. The other fields on the tool use character matching logic.  Please click here for more information on what a true SDN match is.

2. **What does the SDN Search Score mean?**

     The score field indicates the similarity between the name entered and resulting matches on the SDN List. It is calculated using two matching logic algorithms: one based upon phonetics, and a second based upon the similarity of the characters in the two strings. A score of 100 indicates an exact match, while lower scores indicate potential matches.

3. **How do I use the Minimum Name Score field and score slider bar?**

     The minimum name score field limits the number of names returned by the search. A value of 100 will return only names that exactly match the characters entered into the name field. A value of 50 will return all names that are deemed to be 50% similar based upon the matching logic of the search tool. By lowering the match threshold the system will return a broader result set.

4. **How is the Score calculated?**

     SDN search uses two matching logic algorithms, and two matching logic techniques to calculate the score. The two algorithms are Jaro-Winkler, a string difference algorithm, and Soundex, a phonetic algorithm. The first technique involves using the Jaro-Winkler algorithm to compare the entire name string entered against full name strings of SDN entries. The second technique involves splitting the name string entered into multiple name parts (for example, John Doe would be split into two name parts). Each name part is then compared to name parts on the SDN list using the Jaro-Winkler and Soundex algorithms. The search calculates a score for each name part entered, and a composite score for all name parts entered. SDN Search uses both techniques each time the search is run, and returns the higher of the two scores in the Score column.

5. **Does OFAC recommend a specific match threshold score?**

     OFAC cannot make such a recommendation because each search has its own unique set of facts surrounding it. Users of SDN Search must make their own match threshold determinations based upon their own internal risk assessments and established compliance practices.

6. **What fields influence the score?**

     Only the name field influences the score.

7. **What fields use fuzzy logic?**

     Only the name field uses the fuzzy searching logic.
 
 
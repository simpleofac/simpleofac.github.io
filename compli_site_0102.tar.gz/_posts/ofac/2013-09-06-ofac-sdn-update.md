---
layout: post
categories: 
- regulatory
tags:
- OFAC

title:  Government of Iran Listings - September 6, 2013
summary:  Specially Designated Nationals List Update  

---

###{{page.title}}


Specially Designated Nationals List was updated on September 6, 2013.

More information can be found at [http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130906.aspx](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130906.aspx)      

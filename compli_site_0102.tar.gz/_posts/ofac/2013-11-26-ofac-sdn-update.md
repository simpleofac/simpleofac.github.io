---
layout: post
categories: 
- regulatory
tags:
- OFAC

title:  Counter Narcotics Trafficking Sanctions Update - November 26, 2013
summary:  Specially Designated Nationals List Update  

---

###{{page.title}}


Specially Designated Nationals List was updated on November 26, 2013.

More information can be found at [http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20131126.aspx](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20131126.aspx)      

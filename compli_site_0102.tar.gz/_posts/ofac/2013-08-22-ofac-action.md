---
layout: post
categories: 
- regulatory
tags:
- OFAC

title:  OFAC Recent Actions 
summary:  Specially Designated Nationals List Update  

---

###{{page.title}}






####September
- 09/06/2013​	[Government of Iran Listings](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130906.aspx)​ 
- 09/05/2013​	[Release of OFAC Enforcement Information](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130905.aspx)

####August

- 08/22/2013​	[Counter Terrorism Designations; Kingpin Act Designations](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130822.aspx)​
- 08/21/2013​​	[Counter Terrorism Designations; Kingpin Act Designations](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130821.aspx)​​
- 08/20/2013​	[Counter Terrorism Designations; Kingpin Act Designations](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130820.aspx)​
- 08/13/2013​	​[Release of OFAC Enforcement Information](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130813.aspx)​
- 08/08/2013​	​[Notice to users of OFAC's legacy delimited and fixed-width files](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130808.aspx) ​
- 08/07/2013​	​[Issuance of New Burma Executive Order](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130807.aspx)​
- 08/06/2013​	​[Counter Terrorism Designations](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130806.aspx)​
- 08/01/2013	[Kingpin Act Designations](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130801.aspx)

####July

- 07/30/2013​	[Kingpin Act Designations​; Counter Narcotics Removals​​​; Cuba Removals](http://www.treasury.gov/resource-center/sanctions/OFAC-Enforcement/Pages/20130730.aspx)​​​



OFAC SDN List can be download at [http://www.treasury.gov/resource-center/sanctions/SDN-List/Pages/default.aspx](http://www.treasury.gov/resource-center/sanctions/SDN-List/Pages/default.aspx)      

---
layout: post
categories: 
- Knowledge Base
tags:
- AML

title: Money Laundering Methods, Trends and Typologies
summary: Organized crime and narcotics-traffickers have used the following methods for decades to launder their illegal proceeds. These methods continue to be used frequently.
 
---
###{{page.title}}

Organized crime and narcotics-traffickers have used the following methods for decades to launder their illegal proceeds. These methods continue to be used frequently.

 - Financial activity inconsistent with the stated purpose of the business;
 - Financial activity not commensurate with stated occupation;
 - Use of multiple accounts at a single bank for no apparent legitimate purpose;
 - Importation of high dollar currency and traveler's checks not commensurate with stated occupation;
 - Significant and even dollar deposits to personal accounts over a short period;
 - Structuring of deposits at multiple bank branches to avoid Bank Secrecy Act requirements;
 - Refusal by any party conducting transactions to provide identification;
 - Apparent use of personal account for business purposes;
 - Abrupt change in account activity;
 - Use of multiple personal and business accounts to collect and then funnel funds to a small number of foreign beneficiaries;
 - Deposits followed within a short period of time by wire transfers of funds;
 - Deposits of a combination of monetary instruments atypical of legitimate business activity.
 - Movement of funds through countries that are on the FATF list of NCCTs.
 
Money launderers have demonstrated great creativity in combining traditional money laundering techniques into complex money laundering schemes designed to thwart the ability of authorities to prevent, detect and prosecute money laundering.
---
layout: aml
title: AML and Fraud Detection
slug: aml
---

###Our approach to AML and Fraud Detection

AML and Fraud Detection is a build-in module of SimpleCompli platform. 
It uses advanced profiling algorithm and the latest Web 2.0 (AJAX), providing user friendly interface, high performance and quality.
 
<p class="lead">
Major features and functionalities are:
</p>

1.  **Build profiling and rules**  
    It allows compliance officer to profiling entities, such as customers and accounts and build rules to generate alerts for 
    unusual behaviors or activities.
    
2.  **Monitor entity activities**  
    Alerts are generated when an entity's, such as customer or account, activity goes outside their normal behavior range.
    
3.  **Prioritize alerts with evidence and statistics**   
    All alerts are rated with priority and alert score, with details evidence and statistics to help manage review workload, 
    focus on review and investigation.

4.  **Enterprise Case Management.**  
    It has configurable workflow and document management, alert notification and alert forwarding via email, to help manage alerts and cases.

5.	**Built-in support of regulatory reports.**      
    Easily and quickly create and submit a pre-populated Suspicious Activity Report (SAR).


For more information on SimpleCompli AML and Fraud Detection module , please check the [online documentation]({{site.url}}/aml/help/en/).



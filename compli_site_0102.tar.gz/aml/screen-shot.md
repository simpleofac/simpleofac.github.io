---
layout: aml
title: AML Screenshot Tour
slug: aml
---
###AML Screenshot Tour

<div class="row">
  <div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/aml/images/list-management.png">
            <img src="{{site.url}}/aml/images/list-management.png" alt="Manage Sanction List - Browse List"
                    ></a>
			<p><span class="label label-info">List management</span> manages and maintenances the sanction entity list.</p>
	 </div>
 </div>
 <div class="span10">
	 <div class="thumbnail2">
		<a href="{{site.url}}/aml/images/list-analysis-search-result.png">
            <img src="{{site.url}}/aml/images/list-analysis-search-result.png" alt="Manage Sanction List - List Analysis"
                   ></a>                   
			<p><span class="label label-info">List analysis</span> gives users the ability to view the changes on the sanction list between day one and day two</p>
	 </div>
 </div>
  <div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/aml/images/screen-lookup-search-result.png">
            <img src="{{site.url}}/aml/images/screen-lookup-search-result.png" alt="Manage Sanction List - Freetext lookup"
              ></a>
			<p><span class="label label-info">Free text lookup</span>provides hit positions, hit on name or alternative name(Aliases), details sanction list and highlight the match terms.</p>
			
	 </div>
 </div>

<div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/aml/images/wla-result.png">
            <img src="{{site.url}}/aml/images/wla-result.png" alt="Manage Sanction List - Case Management"
                   ></a>
			<p><span class="label label-info">Case management</span> provides alert detail, each hit and hit details, and all actions users performed, documents and audit logs</p>
	 </div>
 </div>

<div class="span10">
	 <div class="thumbnail">
		<a href="{{site.url}}/aml/images/wla-review.png">
            <img src="{{site.url}}/aml/images/wla-review.png" alt="Manage Sanction List - Alert review workflow"
                   ></a>
			<p><span class="label label-info">Configurable workflow</span> allows user to make decision, attach documents, add comments etc on the alert.</p>
	 </div>
 </div>

</div>

For more information on Simple OFAC Suite™ , please check the [online documentation]({{site.url}}help/en/).
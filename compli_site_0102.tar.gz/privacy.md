---
layout: default
title: Privacy
slug: Privacy
---



If you visit our website to read or download information, 
We collect and store only the following information about you: the name of the domain from which you access the Internet; 
the date and time you access our site; and the Internet address of the website from which you linked directly to our site.

We will not obtain personally identifying information about you when you visit our website, 
unless you voluntarily choose to provide such information to us by E-mail or by other forms of communication.

SimpleOFAC Technologies does not give, sell or transfer personal information to third parties, unless required by law, 
such as the Freedom of Information Act (FOIA).

For website management, information is collected for statistical purposes. Computer software programs are used to create summary 
statistics about visits our website which are used for such purposes as assessing what information is of most and least interest, 
determining technical design specifications, and identifying system performance or problem areas. 
No information subject to the Privacy Act, such as name and address, is collected or used for this analysis. 
Raw data logs are used for no other purposes.

Except for authorized law enforcement investigations, no other attempts are made to identify individual users or their usage habits.

###Notice of Monitoring

We may monitor and audit usage of this system, and all persons are hereby notified that use of this system constitutes consent 
to such monitoring and auditing.

Unauthorized attempts to upload information and/or change information on this website is strictly prohibited and are subject to 
prosecution under the Computer Fraud and Abuse Act of 1986 and 18 U.S.C. 1001 and 1030.

###Legal Disclaimer
The information contained in this website is for general guidance on matters of interest only. 
The application and impact of laws can vary widely based on the specific facts involved. Given the changing nature of laws, 
rules and regulations, and the inherent hazards of electronic communication, there may be delays, omissions or inaccuracies in 
information contained in this website. Accordingly, the information on this website is provided with the understanding that the 
authors and publishers are not herein engaged in rendering legal or other professional advice and services. 
As such, it should not be used as a substitute for consultation with professional, legal or other competent advisers.

While We have made every attempt to ensure that the information contained in this website has been obtained from reliable sources, 
We are not responsible for any errors or omissions, or for the results obtained from the use of this information. 
All information in this website is provided "as is", with no guarantee of completeness, accuracy, timeliness or of the results 
obtained from the use of this information, and without warranty of any kind, express or implied, including, 
but not limited to warranties of performance, merchantability and fitness for a particular purpose. 
In no event will SimpleOFAC Technologies, its related partnerships or corporations, or the partners, agents or employees 
thereof be liable to you or anyone else for any decision made or action taken in reliance on the information in this website or 
for any consequential, special or similar damages, even if advised of the possibility of such damages.

Certain links in this website connect to other websites maintained by third parties over whom SimpleOFAC Technologies has no control. SimpleOFAC Technologies makes no representations as to the accuracy or any other aspect of information contained in other websites.

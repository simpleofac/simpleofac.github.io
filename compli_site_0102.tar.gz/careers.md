---
layout: default
title: Careers - Grow with us
slug: careers
---


SimpleOFAC&trade; Technologies is a young and innovative software research and development company, 
specializing in compliance solutions for  
**OFAC, AML, BSA, CIP, KYC, EDD, Employee Trade Complaince**
and other related domestic and foreign governmental regulations.


We are constantly looking for outstanding, bright individuals, who has IT/sales/marketing experience. 
In particular, if you have OFAC/AML, SEC, FINRA compliance related experience, 
please send us your resume to  <a href="mailto:careers@simpleofac.com">careers@simpleofac.com</a>  
 

With the best regards<br/>
SimpleOFAC Team. 

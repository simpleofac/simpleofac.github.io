---
layout: default
title: About Us - Company
slug: company
---





SimpleOFAC&trade; Technologies is a young and innovative software research and development company, 
specializing in compliance solutions for  
**OFAC, AML, BSA, CIP, KYC, EDD, Employee Trade Complaince**
and other related domestic and foreign governmental regulations.

 
Our flagship product, Simple OFAC&trade; Suite, is built on the open extensible platform, 
uses latest Web 2.0 (AJAX) and innovative indexing and search technology, 
providing user friendly interface, 
high performance and quality, 
to help financial institutions to meet the demanding compliance regulations 
by eliminating the risks of processing illegal transactions and detecting high-risk customers.


Our core developers have 30+ years combined experience at leading technology and financial companies, 
with in depth knowledge on indexing and search technologies 
and hand on experience on OFAC/AML compliances in the financial industries.


The company's commitment to excellence and innovation is reflected 
in its significant investment in research and development. We have built AML, ETP (Employee Personal Trade) and SAR/CTR 
modules on the top of SimpleOFAC Suite platform. We will release other compliance related products in the very near future.

**We invite you to download and test our software, try them online, request a WebEX demo, or contact us for further information.**

With the best regards<br/>
SimpleOFAC Team. 

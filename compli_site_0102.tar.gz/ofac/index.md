---
layout: ofac
title: OFAC Overview
slug: ofac
---

###Our approach to OFAC compliance


SimpleOFAC is a built-in module of SimpleCompli Platform. It uses the latest Web 2.0 (AJAX) and innovative indexing and search technology, 
providing user friendly interface, high performance, and quality.
 
<p class="lead">
SimpleOFAC lets you:
</p>

1.  **Manage your sanction List**  
    It supports list upload, including OFAC SDN List, NS-PLC list, Canada OFSI List, and any lists you define in XML or CSV format.

2.  **Scan your customer data and transaction**  
    It supports multiple screening engine instances. 
    The Screening Engine scans texts/messages against the sanction list, and gives alert or no alert results.

3.  **Review your scan results (alerts or suspicious hits)**   
    The screening result can be loaded into the Case Management System for review. It has a build-in algorithm to detect duplicated texts/messages.

4.  **Track your data**  
    All the data changes, either by operator or by automatic process, are stored in the system. This not only serves as audit purpose, but can also be used to restore the data to any past point in time.

5.	**Test your data quality**      
    It provides a very handy free text lookup tool to let you quickly scan any customer data or transaction. It also can be used as a test tool to test the quality of the Screening Engine and the Sanction List.

6.	**Report your Statistics**  
    It provides comprehensive data analysis on sanction list changes, customer data changes, and hit (alert) rates. It helps us with tuning our Sanction List and Screening Engine to reduce false alerts and save money.

7.	**Customize to match to your business processes**  
    More than just an OFAC tool, Simple OFAC Suite™ is an extensible platform that you can customize to match to your business processes.

8.	**Enhance your processes and save money**      
    It will dynamically enhance your Due Diligence processes, Know Your Customer (KYC) practices, and save resources and money.


For more information on SimpleOFAC, please check the [online documentation]({{site.url}}/ofac/help/en/overview.html).



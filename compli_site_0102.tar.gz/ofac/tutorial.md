---
layout: ofac
title: 5 minutes tutorial
slug: ofac
---
### 5 minutes tutorial


SimpleOFAC is a pure-Java server-side web application. 
It runs on any platform (Windows, Unix, Linux ) and supports most Relational Databases (Oracle, MYSQL, Microsoft SQL). 

Please follow the [Installation manual]({{site.url}}/ofac/help/en/installation.html) to set it up and running. 

Login with the admin ID and begin the test drive following these easy steps:

1.  **Add or Upload your sanction List**  
    You can either manually add the sanction list via List management [Add new Sanction Entry]({{site.url}}help/en/list/listentry.html#list-listentry-new), 
    or get the sanction list from various government websites, 
    such as OFAC SDN List, NS-PLC list and then upload the list via [List Upload Screen]({{site.url}}help/en/list/listupload.html). 

2.  **Create Screening Instance**  
    Create a [new Screening instance]({{site.url}}/ofac/help/en/screen/screeninstance.html#screen-instance-new) via Screening management screen 
    and then use "Configure" function to configure the sanction lists to be included in the screening index. 
    Finally, use the "Build Index" function to build the index.

3.  **Free text search or File Screening**   
    You are ready to go. You can search your customer or transaction via
    [Free Text Lookup screen]({{site.url}}/ofac/help/en/screen/freetextlookup.html)
 or batch [file scan] ({{site.url}}/ofac/help/en/screen/filescan.html) .


For more information on SimpleOFAC, please check the [Online documetation]({{site.url}}/ofac/help/en/).